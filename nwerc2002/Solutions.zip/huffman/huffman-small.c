#include <stdio.h>
char S[200],*L[200];p(i){--i?p(i):0;printf("%d->%.*s\n",i,L[i+1]
-L[i],L[i]);}int T,N,Z,i,H[200],*P=H;f(s,n,o,l)char*s;int*n;{o?o
<=Z-l&&*n?*n<0?*n=0,f(L[l+1]=s,H,o-1,l+1),*n=P-H,memset(P,-1,4*N
),P+=N,f(s,n,o+N-1,l),P-=N,*n=-1:*s?f(s+1,H+*n+*s-48,o,l):0:0:Z-
l||*s?0:p(l);}main(){for(freopen("g.in","r",stdin),scanf("%d",&T
),*P++=-1,*L=S;T--;f(S,H,1,0))scanf("%d%d%s",&Z,&N,S);return 0;}
