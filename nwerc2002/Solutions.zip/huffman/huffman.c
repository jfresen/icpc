#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

typedef struct huffnode {
	struct huffnode **nodes,*parent;
	int leaf,used;
} huffnode;

int nrnodes,nrchars,arity,nodesleft,maxdepth;
huffnode *root,*gnodes,**snodes;
char temp[200];

int g,nindex;
huffnode* getfreenode(huffnode*parent) {
	g=nindex++;
	/*for (g=0;g<nrnodes;g++)*/
		if (!gnodes[g].used) {
			++gnodes[g].used;
			gnodes[g].leaf=0;
			memset(gnodes[g].nodes,0,sizeof(gnodes[g].nodes));
			gnodes[g].parent=parent;
			return &gnodes[g];
		}
	return NULL;
}

void PrintNode(int j, huffnode* node) {
	if (node->parent) {
		int i;
		PrintNode(j,node->parent);
		for (i=0;i<arity;i++)
			if(node->parent->nodes[i]==node)
				printf("%d",i);
	} else
		printf("%d->",j);
}

int VClosedTree(huffnode* node) {
  int i;
  
  if (node->leaf)
    return 1;
  for (i=0;i<arity;i++) {
	if (!node->nodes[i])
		  return 0;
    	if (!VClosedTree(node->nodes[i]))
      		return 0;
  }
  return 1;
}

void MakeHuffman(char*,int);

void OneNode(huffnode*node, char*str, int count, int todo) {
	huffnode *target;
	if (!todo || !strlen(str) || nodesleft<0) 
		return;

	if (!node->nodes[*str-'0']) {
		node->nodes[*str-'0'] = getfreenode(node);
	}
	else
		node->nodes[*str-'0']->used++;
		
	target = node->nodes[*str-'0'];
	if (target->leaf) {
		--target->used;
		return;
	}
	if (target->used==1) {
		target->leaf=1;
		snodes[nrchars-count]=target;
		MakeHuffman(str+1,count-1);
		target->leaf=0;
		nodesleft-=arity;
	}

	OneNode(target, str+1, count, todo-1);
	
	if (!--target->used) {
		nodesleft+=arity;
		node->nodes[*str-'0'] = NULL;
		--nindex;
	}
}

void MakeHuffman(char *str, int count) {
	if (nodesleft<0 || (!count && (strlen(str) || nodesleft)))
		return;
	if (!count) {
		if (VClosedTree(root)) {
			for (g = 0; g < nrchars; g++) {
				PrintNode(g,snodes[g]);
				printf("\n");
			}
		}
		return;
	}
	OneNode(root, str, count, maxdepth);
}

int main() {
  int run;
  char str[10000];
  freopen("g.in","r",stdin);
  scanf("%d",&run);
  gnodes = (huffnode*) calloc(10000, sizeof(huffnode));
  snodes = (huffnode**) calloc(10000, sizeof(huffnode*));
  for (g=0;g<10000;g++)
	  gnodes[g].nodes=(huffnode**)calloc(10, sizeof(huffnode*));
  while ((run--) > 0) {
	  nindex=0;
    scanf("%d%d%s",&nrchars,&arity,str);
    maxdepth = (nrchars - 1) / (arity - 1);
    nodesleft = nrnodes = maxdepth+nrchars;
    for (g=0;g<10000;g++)
	    gnodes[g].used=0;
    root = getfreenode(NULL);
    nodesleft-=arity+1;
    MakeHuffman(str,nrchars);
  }
  return 0;
}
