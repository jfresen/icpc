#include <stdio.h>

#define OPEN (-1)
#define LEAF (-2)

int   N;               // arity of tree
int   Z;               // number of source symbols
int   H[10000], *HP;   // dynamically maintained huffman-tree
char *L[10000];        // end-of-leave indices
char  S[10000];

int NSOL;

// *s ...........: current input symbol (N-ary digit)
// node .........: 'pointer' to the current node
// no ...........: number of 'open' nodes in tree
// nl ...........: number of 'leave' nodes in tree

void find_symbols(char *s, int *node, int no, int nl)
{ 
  if (no) // are there open leaves left (i.e., is the tree incomplete?)
    {
      if (no<=Z-nl) // otherwise, it's impossible to find a solution
	
	// the node at this point is either OPEN, LEAF,
	// or the H-array index of N sub-trees
	
	switch(*node)
	  {
	  case OPEN:
	    
	    // try possibility #1:
	    // place a LEAF here, and restart from root
	    
	    *node=LEAF;
	    L[nl+1]=s;
	    find_symbols(s, H, no-1, nl+1);
	    
	    // try possibility #2:
	    // fan-out the OPEN node (make it an internal node);
	    // it becomes the parent node of N new OPEN nodes.
	    
	    *node=(HP-H);
	    for(int i=0;i<N;i++) *HP++=OPEN;
	    find_symbols(s, node, no+N-1, nl);
	    
	    // restore the tree
	    HP-=N;
	    *node=OPEN;

	    // fallthrough

	  case LEAF:
	    // obvious non-solution: we've already been here!
	    break;
	    
	  default:
	    if (*s)
	      find_symbols(s+1, H+*node+*s-'0', no, nl);
	  }
    }
  else
    {
      // no open leaves left. If all characters have been placed,
      // and we're at end-of-header, this is a solution:
      if (nl==Z && !*s)
	{
	  ++NSOL;
	  for(int i=0;i<nl;i++)
	    {
	      printf("%d->%.*s\n", i, L[i+1]-L[i], L[i]);
	    }
	}
    }
}

int main(void)
{
  int T; // number of test-cases
  freopen("g.in", "r", stdin);
  scanf("%d", &T);
  // set root node status to 'open'
  HP=H; // HP points to the first free node of the H-array
  *HP++=OPEN;
  L[0]=S;
  while(T--)
    {
      scanf("%d%d%s", &Z, &N, S);

      //fprintf(stderr, "Z %d N %d <%s>\n", Z, N, S);
      // try placing all symbols
      NSOL=0;
      find_symbols(S,H,1,0);
      //fprintf(stderr, "Z %d N %d string %s nsol %d\n", Z, N, S, NSOL);
    }
  return 0;
}
