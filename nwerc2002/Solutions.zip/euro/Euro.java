/*
	Solution in Java of the Euro Problem, for EKP2002
	Author	Peter G.Kluit
	Date	March 2002
	Revised for new output format November 2002
 */

import java.io.*;
import java.util.*;

public class Euro{

	private static final String INFILE	= "a.in";

	public static void main(String [] args){
		try{
			 InputStream	in = new FileInputStream(INFILE);
			 IntReader ir = new IntReader(in);

			 int aantal = ir.read();
			 for (int count = 1 ; count <= aantal; count++)
			 {
				CoinsProblem problem	= new CoinsProblem(ir);
				problem.solve();
				System.out.println(problem.getSolution());
			 }
			 in.close();
		}
		catch (IOException ioe){
			System.out.println(ioe);
		}
	}
}

class CoinsProblem{

	public static final int MUNTAANTAL = 6;
	public static final int MAXBEDRAG  = 100;
	public static final int INF 			 = 1000000;

	private int [] munten = new int [MUNTAANTAL];
	private int [] wissel = new int [MAXBEDRAG + 1];
	int maxwaarde = 1;

	public CoinsProblem(IntReader ir){
		for (int k = 0; k < MUNTAANTAL; k++)
			munten[k] = ir.read();
		for (int waarde = 1; waarde <= MAXBEDRAG; waarde++)
			wissel[waarde] = INF;
		for (int k = 0; k < MUNTAANTAL; k++)
			put(munten[k], 1);
	}

	public CoinsProblem(int [] coins){
		munten = coins;
		for (int waarde = 1; waarde <= MAXBEDRAG; waarde++)
			 wissel[waarde] = INF;
		for (int k = 0; k < MUNTAANTAL; k++)
			 put(munten[k], 1);
	}

	public void solve(){
		 for (int wissels = 1;!done(); wissels++)
			for (int waarde = 1; waarde <= maxwaarde; waarde++)
				if (wissel[waarde] == wissels)
					for (int munt = 0; munt < MUNTAANTAL; munt++){
						put (waarde + munten[munt], wissels + 1);
						put (waarde - munten[munt], wissels + 1);
					}
	}

	private String averageToString(){
		 double average = average();
		 int gemiddelde = (int)(100 * average + 0.1);
		 int kop = gemiddelde / 100;
		 int staart = gemiddelde % 100;
		 String kopstring = kop + "";
		 String staartstring = "" + staart;
		 while (staartstring.length() < 2)
				staartstring += '0';
		 return kopstring + "." + staartstring;
	}

	public String getSolution(){
		 return averageToString() + " " + worst();
	}

	public int worst(){
		int antwoord = 0;
		for(int waarde = 1; waarde <= MAXBEDRAG; waarde++)
			 if (antwoord < wissel[waarde])
				antwoord = wissel[waarde];
		return antwoord;
	}

	public double average(){
		double totaal = 0.0;
		for(int waarde = 1; waarde <= MAXBEDRAG; waarde++)
			totaal += wissel[waarde];
		return totaal / MAXBEDRAG ;
	}

	private boolean done(){
		int waarde = 1;
		while (waarde < MAXBEDRAG && wissel[waarde] < INF)
			waarde ++;
		return wissel[waarde] < INF;
	}

	private void put(int waarde, int aantal){
		waarde = Math.abs(waarde);
		ensure(waarde);
		if (wissel[waarde] > aantal)
			wissel[waarde] = aantal;
		if (waarde > maxwaarde)
			maxwaarde = waarde;
	}

	private void ensure(int m){
		int size = wissel.length;
		int newSize = size;
		while (newSize <= m)
			newSize = newSize * 2;
		if (newSize > size){
			int [] newWissel = new int [newSize];
			for (int k = 1; k < size; k++)
			 newWissel[k] = wissel[k];
			for (int k = size; k < newSize; k++)
			 newWissel[k] = INF;
			wissel = newWissel;
		}
	}

	public void dumpWissel(){
		System.out.println("dump van wissel");
		for (int waarde = 1; waarde <= maxwaarde; waarde++)
			System.out.println( waarde + "	 " + wissel[waarde]);
	}

	public void dumpCoins(){
		System.out.print("dump van munten:	");
		for (int k = 0; k < MUNTAANTAL; k++)
			System.out.print( " " + munten[k]);
		System.out.println( );
	}
}

class IntReader extends StreamTokenizer{

	public IntReader(InputStream is){
		super(new BufferedReader(new InputStreamReader(is)));
	}

	public int read(){
		try{
			int tokentype = nextToken();
		}
		catch(IOException iox){
			System.out.println(iox);
		}
		return (int) nval;
	}
}
