#include <stdio.h>
main(){int C[6],R[201],T,Z,S,i,j,W;for(freopen("a.in","r",stdin),scanf("%d"
,&T);T--;printf("%.2f %d\n",W/100.,S)){for(i=0;i<6;i++)scanf("%d",C+i);for(
memset(R,-1,804),Z=200,R[100]=S=W=0;Z;S++)for(i=0;i<201;i++)if (R[i]==S)for
(j=0;j<6;j++)i+C[j]<201&&R[i+C[j]]<0?W+=(i+C[j]>100)*(R[i+C[j]]=S+1),--Z:0,
i-C[j]>= 0&&R[i-C[j]]<0?W+=(i-C[j]>100)*(R[i-C[j]]=S+1),--Z:0;}return 0;}
