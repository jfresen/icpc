import java.io.*;
import java.util.*;

public class Floors{
    private static final String INFILE = "d.in";

    public static void main(String [] args){
        try{
            FileReader fis = new FileReader(INFILE);
            FloorReader ir = new FloorReader(fis);

            for (int cases = ir.read(); cases > 0; cases--){
                Problem problem = new Problem(ir);
                problem.solve();
                System.out.println(problem.getSolution());
            }
        }
        catch (IOException iox){}
    }
}

class Problem{
    Stack floors;
    Floor floor;

    int maxArea = 0;

    public Problem(FloorReader ir){
        floor = ir.readFloor();
        int tiles = ir.read();
        for (int k = 0; k < tiles; k++){
            Tile tile = ir.readTile();
            floor.merge(tile.top());
            floor.merge(tile.base());
            floor.merge(tile.left());
            floor.merge(tile.right());
        }
    }

    public void solve(){
      floors = new Stack();
      floors.push(floor);
        while (! floors.empty()){
            Floor floor = (Floor) floors.pop();
            if (floor.area() > maxArea)
                if (floor.isSplittable()){
                    floor.split();
                    floors.push(floor.part1);
                    floors.push(floor.part2);
                }
                else
                    maxArea = floor.area();
        }
    }

    public void solveR(){
        divide(floor);
    }

    private void divide(Floor floor){
      if (floor.area() > maxArea)
        if (floor.isSplittable()){
          floor.split();
          divide(floor.part1);
          divide(floor.part2);
        }
        else
           maxArea = floor.area();
    }

    public String getSolution(){
        return "" + maxArea;
    }

    public String toString(){
        return floors.peek().toString();
    }
}

class Floor extends Rectangle{
    Vector lines = new Vector();
    Line splitter;
    Floor part1, part2;

    public Floor(int xl, int yl, int xh, int yh){
        super(xl, yl, xh, yh);
    }

    public boolean isSplittable(){
        return splitter != null;
    }

    public void split(){
        if (splitter.isHorizontal()){
            part1 = new Floor(xlow, ylow, xhigh, splitter.yhigh);
            part2 = new Floor(xlow, splitter.ylow, xhigh, yhigh);
        }
        else{
            part1 = new Floor(xlow, ylow, splitter.xhigh, yhigh);
            part2 = new Floor(splitter.xlow, ylow, xhigh, yhigh);
        }
        Enumeration e = lines.elements();
        while (e.hasMoreElements()){
            Line line = (Line) e.nextElement();
            part1.clip(line);
            part2.clip(line);
        }
    }

    public void addLine(Line lijn){
        if (isInterior(lijn)){
            lines.addElement(lijn);
            if (splitter == null && isSplitting(lijn))
                splitter = lijn;
        }
    }

    public void merge(Line lijn){
        for (int index = lines.size() - 1 ; index >= 0; index--){
            Line present = (Line) lines.elementAt(index);
            if (present.mergeable(lijn)){
                lijn.merge(present);
                lines.remove(present);
            }
        }
        addLine(lijn);
    }

    public int area(){
        return (xhigh  - xlow) * (yhigh - ylow);
    }

    public String toString(){
        String antwoord = xlow + " " + ylow + " " + xhigh + " " + yhigh + "\n";
        antwoord += "Splitter: \n";
        if (splitter != null)
          antwoord += splitter.toString() + "\n";
        Enumeration e = lines.elements();
        while (e.hasMoreElements()){
            Line line = (Line) e.nextElement();
            antwoord += line.toString() + "\n";
        }
        return antwoord;
    }

    public void clip(Line line){
        int nxlow  = Math.max(this.xlow , line.xlow );
        int nxhigh = Math.min(this.xhigh, line.xhigh);
        int nylow  = Math.max(this.ylow , line.ylow );
        int nyhigh = Math.min(this.yhigh, line.yhigh);
        if ((nxlow <  nxhigh && nylow == nyhigh) ||
            (nxlow == nxhigh && nylow <  nyhigh))
            addLine(new Line(nxlow, nylow, nxhigh, nyhigh));
    }

    private boolean isInterior(Line line){
        if (line.isVertical())
            return (this.xlow < line.xlow && line.xlow < this.xhigh);
        else
            return (this.ylow < line.ylow && line.ylow < this.yhigh);
    }

    private boolean isSplitting(Line line){
        if (line.isVertical())
            return (this.ylow == line.ylow && line.yhigh == this.yhigh);
        else
            return (this.xlow == line.xlow && line.xhigh == this.xhigh);
    }
}

class Rectangle{
    int xlow, xhigh, ylow, yhigh;

    public Rectangle(int xl, int yl, int xh, int yh){
        xlow  = xl;
        ylow  = yl;
        xhigh = xh;
        yhigh = yh;
    }
}

class Tile extends Rectangle
{
    public Tile(int xl, int yl, int xh, int yh){
        super(xl, yl, xh, yh);
    }

    public Line base(){
        return new Line(xlow, ylow, xhigh, ylow);
    }

    public Line top(){
        return new Line(xlow, yhigh, xhigh, yhigh);
    }

    public Line left(){
        return new Line(xlow, ylow, xlow, yhigh);
    }

    public Line right(){
        return new Line(xhigh, ylow, xhigh, yhigh);
    }
}

class Line extends Rectangle{
    public Line(int xl, int yl, int xh, int yh){
        super(xl, yl, xh, yh);
        if ( !(xl <  xh && yl == yh) &&
             !(xl == xh && yl <  yh))
             throw new RuntimeException(" foute lijn ");
    }

    public boolean mergeable(Line that){
        if (this.isVertical() && that.isVertical())
            return this.xlow == that.xlow && !(this.yhigh < that.ylow || that.yhigh < this.ylow);
        if (this.isHorizontal() && that.isHorizontal())
            return this.ylow == that.ylow && !(this.xhigh < that.xlow || that.xhigh < this.xlow);
        return false;
    }

    public void merge (Line that){
        xlow  = Math.min(this.xlow , that.xlow );
        xhigh = Math.max(this.xhigh, that.xhigh);
        ylow  = Math.min(this.ylow , that.ylow );
        yhigh = Math.max(this.yhigh, that.yhigh);
    }

    public boolean isHorizontal(){
        return ylow == yhigh;
    }

    public boolean isVertical(){
        return xlow == xhigh;
    }

    public String toString(){
        if (isHorizontal())
            return "hor  " + "y = " + ylow + " , " + xlow + " - " + xhigh;
        else
            return "vert " + "x = " + xlow + " , " + ylow + " - " + yhigh;
    }
}

class FloorReader extends StreamTokenizer{
    public FloorReader(Reader is){
        super(is);
    }

    public int read(){
        try{
            int tokentype = nextToken();
        }
        catch(IOException iox){}
        return (int) nval;
    }

    public Floor readFloor(){
        int x = read();
        int y = read();
        return new Floor(0, 0, x, y);
    }

    public Tile readTile(){
        int xl = read();
        int yl = read();
        int xh = read();
        int yh = read();
        return new Tile(xl, yl, xh, yh);
    }
}

