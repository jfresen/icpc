/*
 *  Solution to the problem "Floors".
 *  Joris van Rantwijk, Apr 2002.
 */

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/* Input limits */
#define MAXSIZE		(40000)
#define MAXTILES	(100)

/* Input/Output streams */
FILE *inf, *outf;

/* Problem description */
int flength, fwidth;
int ntiles;
int tilexl[MAXTILES], tilexh[MAXTILES];
int tileyl[MAXTILES], tileyh[MAXTILES];
int tilearea[MAXTILES];

/* Current set of pieces */
int npieces;
int tiles_by_piece[MAXTILES];	/* Tile nrs grouped by piece */
int piece_offset[MAXTILES];	/* Offset into tile_xx_sorted arrays */
int piece_ntiles[MAXTILES];	/* Nr of tiles in this piece */
int piece_area[MAXTILES];	/* Area of this piece */

/* Solution */
int best_area;


/*
 *  Read description of a floor
 */
void read_input()
{
	int i;

	fscanf(inf, "%d %d\n", &flength, &fwidth);
	assert(flength > 0 && flength <= MAXSIZE);
	assert(fwidth > 0  && fwidth <= MAXSIZE);

	fscanf(inf, "%d\n", &ntiles);
	assert(ntiles >= 1 && ntiles <= MAXTILES);

	for (i = 0; i < ntiles; i++) {
		int xl, xh, yl, yh;
		fscanf(inf, "%d %d %d %d\n", &xl, &yl, &xh, &yh);
		assert(xl >= 0 && xl < xh && xh <= flength);
		assert(yl >= 0 && yl < yh && yh <= fwidth);
		tilexl[i] = xl;  tilexh[i] = xh;
		tileyl[i] = yl;  tileyh[i] = yh;
		tilearea[i] = (xh - xl) * (yh - yl);
	}
}


/*
 *  Compute and store the area of the specified piece.
 */
static void fix_piece_area(int piece)
{
	int offs = piece_offset[piece];
	int n = piece_ntiles[piece];
	int area = 0;
	int i;
	for (i = 0; i < n; i++)
		area += tilearea[tiles_by_piece[offs+i]];
	piece_area[piece] = area;
}


/* Helper function for qsort-ing integers */
static int compare_int(const void *ap, const void *bp)
{
	int a = *(int*)ap, b = *(int*)bp;
	return (a < b) ? -1 : (a > b) ? 1 : 0;
}

/*
 *  Cut this piece if possible. If (fixy) then try to cut along a
 *  fixed-Y line, else try to cut along a fixed-X line.
 *  Return 1 if the cut was successful.
 */
static int try_cut_piece_1d(int piece, int fixy)
{
	int offs = piece_offset[piece];
	int n = piece_ntiles[piece];
	const int *tilelow, *tilehigh;
	int lbounds[MAXTILES], hbounds[MAXTILES];
	int n_intervals, cut, newoffs, newpiece;
	int i, j;

	/*
	 * tilelow[] and tilehigh[] are the lower and upper coordinates
	 * of the tiles for the dimension we are considering.
	 */
	tilelow =  (fixy) ? tileyl : tilexl;
	tilehigh = (fixy) ? tileyh : tilexh;
	
	/*
	 * Find the set of 1D-intervals of all tiles in the specified piece.
	 * Eliminate empty intervals (they don't block any cuts anyway).
	 * Produce a sorted list of the lower bounds and upper bounds of
	 * the resulting intervals.
	 */

	n_intervals = 0;
	for (i = 0; i < n; i++) {
		int tile, low, high;
		tile = tiles_by_piece[offs+i];
		low = tilelow[tile];
		high = tilehigh[tile];
		assert(high >= low);
		if (high > low) {
			lbounds[n_intervals] = low;
			hbounds[n_intervals] = high;
			n_intervals++;
		}
	}

	qsort(lbounds, n_intervals, sizeof(int), compare_int);
	qsort(hbounds, n_intervals, sizeof(int), compare_int);

	/*
	 * Now find a non-trivial point which is not an internal point
	 * of any given interval. At such points we can safely cut the
	 * floor piece without breaking any tiles.
	 * NOTE that this algorithm does NOT work if the set contains
	 * empty intervals, that's why we explicitly leave them out.
	 */

	i = 0;
	j = 0;
	cut = -1;
	/* Scan interval bounds in order */
	while (i < n_intervals && j < n_intervals) {
		/* We prefer closing an interval over opening a new one */
		if (lbounds[i] < hbounds[j])
			i++;
		else
			j++;
		assert(i >= j);
		/* If there are no open intervals, we have a safe cut point */
		if (i == j) {
			cut = hbounds[j-1]; 
			break;
		}
	}

	/* Return failure if no cut point was found */
	if (cut == -1)
		return 0;

	/*
	 * Ok, so now just split tile-set of this piece according
	 * to the cut coordinate.
	 */

	/* Re-arrange the tiles_by_piece array to separate the two pieces */
	i = offs;
	j = offs + n - 1;
	while (i <= j) {
		/* Sweep i from start to end until we see a misplaced tile */
		while (i <= j && tilehigh[tiles_by_piece[i]] <= cut)
			i++;
		/* Sweep j from end to start until we see a misplaced tile */
		while (i <= j && tilelow[tiles_by_piece[j]] >= cut)
			j--;
		/* Swap the out-of-place tiles */
		if (i < j) {
			int ti = tiles_by_piece[i];
			int tj = tiles_by_piece[j];
			tiles_by_piece[i] = tj;
			tiles_by_piece[j] = ti;
			i++;
			j--;
		}
	}

	/* A bit of loop invariant magic proves that we can now safely
	   split the tile-set at index i */
	newoffs = i;
	assert(newoffs > offs && newoffs < offs + n);

	/* Update piece administration */
	newpiece = npieces++;
	piece_ntiles[piece] = newoffs - offs;
	piece_offset[newpiece] = newoffs;
	piece_ntiles[newpiece] = n + offs - newoffs;

	/* Recompute areas */
	fix_piece_area(piece);
	fix_piece_area(newpiece);

	/* Check that I didn't mess it up */
	for (i = 0; i < piece_ntiles[piece]; i++)
		assert(tilehigh[tiles_by_piece[offs+i]] <= cut);
	for (i = 0; i < piece_ntiles[newpiece]; i++)
		assert(tilelow[tiles_by_piece[newoffs+i]] >= cut);

	/* Return success */
	return 1;
}


/*
 *  Cut this piece if possible. Return 1 if the cut was succesful.
 */
int try_cut_piece(int piece)
{
	/* Try cutting along a fixed-X line (cut parallel to Y-axis) */
	if (try_cut_piece_1d(piece, 0))
		return 1;

	/* Try cutting along a fixed-Y line (cut parallel to X-axis) */
	if (try_cut_piece_1d(piece, 1))
		return 1;

	/* Return failure if no cut is possible */
	return 0;
}


/*
 *  Solve the floor problem by repeatedly cutting the largest piece
 *  until this is no longer possible.
 */
void solve(void)
{
	int i, largest_piece;

	/* Start with a single piece containing the whole floor. */
	npieces = 1;
	piece_offset[0] = 0;
	piece_ntiles[0] = ntiles;
	for (i = 0; i < ntiles; i++)
		tiles_by_piece[i] = i;
	fix_piece_area(0);

	/* Repeatedly cut a piece into smaller pieces */
	while (1) {
		/* Find current largest piece */
		largest_piece = 0;
		for (i = 1; i < npieces; i++)
			if (piece_area[i] > piece_area[largest_piece])
				largest_piece = i;

		/* Cut it if possible, else stop cutting */
		if (! try_cut_piece(largest_piece))
			break;
	}

	/* Store area of the largest piece */
	best_area = piece_area[largest_piece];
}


/*
 *  Output the problem solution.
 */
void write_output(void)
{
	fprintf(outf, "%d\n", best_area);
}


/*
 *  Main program.
 */
int main(void)
{
	int nfloor, i;

	inf = fopen("d.in","r");
	outf = stdout;

	fscanf(inf, "%d\n", &nfloor);

	for (i = 0; i < nfloor; i++) {
		read_input();
		solve();
		write_output();
	}

	return 0;
}

/* End */
