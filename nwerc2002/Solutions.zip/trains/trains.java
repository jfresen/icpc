/*** trains.java by David Solinger
****
**** Recursive solution:
**** Every recursion a list of time-probability combinations is taken to be all probalities to
**** arive at that station at the given time. Then, for each neighbour station, we make a new
**** list of time-probability combinations. We check recursively, which of the neighbour stations
**** we can take best.
****
**** ICPC NWERC 2002, Delft   ***/


import java.io.*;
import java.util.*;


public class trains
{
    
    public static final void main (String args[])
    {
        new trains();
    }
    
    
    int n;
    int a, b, ta, tb;
    final int MAX = 12;
    Vector[][] trains = new Vector[MAX][MAX];
    
    
    public trains ()
    {
        StringTokenizer st;
        int runs, i, j, k, n, a, b;
        solution sol;

        try
        {
            BufferedReader br = new BufferedReader(new FileReader("b.in"));
            
            // Read the number of runs
            runs = Integer.parseInt(br.readLine());
            for (i = 0; i < runs; i++)
            {
                // Read the number of trains
                n = Integer.parseInt(br.readLine());
                
                // Init the trains array
                for (j = 0; j < MAX; j++)
                    for (k = 0; k < MAX; k++) trains[j][k] = new Vector();
                    
                // Read all the trains
                for (j = 0; j < n; j++)
                {
                    st = new StringTokenizer(br.readLine()," :");
                    train t = new train();
                    a = st.nextToken().charAt(0) - 'A';
                    t.ta = Integer.parseInt(st.nextToken()) * 60 + Integer.parseInt(st.nextToken());
                    b = st.nextToken().charAt(0) - 'A';
                    t.tb = Integer.parseInt(st.nextToken()) * 60 + Integer.parseInt(st.nextToken());
                    t.p = 1 - (Double.valueOf(st.nextToken())).doubleValue();
                    // Add the train to the sorted trains array
                    AddTrainToSortedArray(a,b,t);
                }
                
                // Read the begin and goal stations and times
                st = new StringTokenizer(br.readLine()," :");
                this.a = st.nextToken().charAt(0) - 'A';
                this.ta = Integer.parseInt(st.nextToken()) * 60 + Integer.parseInt(st.nextToken()) - 1;
                this.b = st.nextToken().charAt(0) - 'A';
                this.tb = Integer.parseInt(st.nextToken()) * 60 + Integer.parseInt(st.nextToken());
                
                Vector v = new Vector();
                solution s = new solution(""+(char)(this.a + (int)'A'),1,this.ta,this.a);
                v.addElement(s);
                PrintSolution(Solve(v));
            }
        }
        catch (Exception e) { System.err.println(e); }
    }
    
    
    void AddTrainToSortedArray (int a, int b, train t)
    {
        if (trains[a][b].size() == 0) trains[a][b].addElement(t);
        else
        {
            for (int i = 0; i < trains[a][b].size(); i++)
            {
                train t2 = (train)trains[a][b].elementAt(i);
                if (t.ta < t2.ta) {
                    trains[a][b].insertElementAt(t,i);
                    return;
                }
            }
            trains[a][b].addElement(t);
        }
    }
     
    
    solution Solve (Vector v)
    {
        solution s = (solution)v.firstElement();
        int place = s.c;
        if (place == this.b)
        {
            solution best = s;
            // If we are at the destination add all probabilities and return this in a 'solution'
            for (int i = 1; i < v.size(); i++)
            {
                s = (solution)v.elementAt(i);
                best.p += s.p;
            }
            return best;
        }
        else
        {
            double p_over, p;
            solution best = new solution("",0,0,0);
            // We are going to check all other stations
            for (int i = 0; i < MAX; i++)
            {
                // We are going to make a new list of 'solutions' to go to station 'i'
                Vector new_v = new Vector();
                // Loop through the list of 'solutions' to go to the current station
                for (int k = 0; k < v.size(); k++)
                {
                    p_over = 1;
                    // Check all trains going from the current station to station 'i'
                    for (int j = 0; j < (trains[place][i]).size(); j++)
                    {
                        train t = (train)((trains[place][i]).elementAt(j));
                        s = (solution)(v.elementAt(k));
                        // Check whether this train is on time
                        if (t.ta > s.t && t.tb <= this.tb)
                        {
                            p = t.p * p_over;
                            p_over -= p;
                            // Add a new 'solution' to the new list of 'solutions' with the correct 'p'
                            new_v.addElement(new solution(s.s+" "+(char)(i+(int)'A'),p*s.p,t.tb,i));
                        }
                    }
                }
                if (!(new_v.isEmpty())) 
                {
                    // If we have some 'solutions' in the new list, we try to solve the problem with this list
                    s = Solve(new_v);
                    // Now check if it's the best (so far) to go to station 'i'
                    if (s.p > best.p) best = s;
                }
            }
            return best;
        }
    }
    
    
    void PrintSolution (solution s)
    {
        String str_p = "" + ((double)Math.round(s.p*10000))/10000;
        int len = str_p.length();
        for (int i = len; i < 6; i++) str_p += "0";
        System.out.println(s.s+"\n"+str_p);
    }
    
    
    class train
    {
        int ta;     // time of leaving
        int tb;     // arrival time
        double p;   // probability
    }
    
    
    class solution
    {
        String s;   // String with station letters
        double p;   // probalility
        int t;      // time
        int c;      // current station
        
        solution (String ps, double pp, int pt, int pc) { s = ps; p = pp; t = pt; c = pc; }
    }
}
