import java.io.*;
import java.util.*;

public class Input{
    private static final String INFILE = "h.in";

    public static void main(String [] args){
        try{
            String infile = INFILE;
            if (args.length > 0)
                infile = args[0];
            FileReader fis = new FileReader(infile);
            ProblemReader ir = new ProblemReader(fis);

            for (int cases = ir.read(); cases > 0; cases--){
                Problem problem = new Problem(ir);
                //System.out.println(problem.toString());
                problem.solve();
                System.out.println(problem.getSolution());
            }
            //System.in.read();
        }
        catch (IOException iox){}
    }
}

class Problem{

    Rectangle floor;
    RectangleSet tiles = new RectangleSet();
    String solution;

    public Problem (ProblemReader pr){
        floor = pr.readFloor();
        int tileno = pr.read();
        for (int k = 0; k < tileno; k++){
            Rectangle tile = pr.readRectangle();
            tiles.add(tile);
        }
    }

    public void solve(){
        if (!tiles.areDisjoint())
            solution = "NONDISJOINT";
        else if (!tiles.containedIn(floor))
            solution = "NONCONTAINED";
        else if (tiles.sumOfAreas() != floor.area())
            solution = "NONCOVERING";
        else
            solution = "OK";
    }

    public String getSolution(){
        return solution;
    }
}

class ProblemReader extends StreamTokenizer{

    public ProblemReader(Reader is){
        super(is);
    }

    public int read(){
        try{
            int tokentype = nextToken();
        }
        catch(IOException iox){}
        return (int) nval;
    }

    public Rectangle readFloor(){
        int x = read();
        int y = read();
        return Rectangle.make(0, 0, x, y);
    }

    public Rectangle readRectangle(){
        int xl = read();
        int yl = read();
        int xh = read();
        int yh = read();
        return Rectangle.make(xl, yl, xh, yh);
    }
}

class Interval{
    private int low, high;

    public Interval(int a, int b){
        low  = a;
        high = b;
    }

    public String toString(){
      return "(" + low + "," + high + ")";
    }

    public static Interval make(int a, int b){
        if (a < b)
            return new Interval(a,b);
        else
            return null;
    }

    public int length(){
        return high - low;
    }

    public Interval intersection(Interval other){
        int ilow  = Math.max (this.low , other.low );
        int ihigh = Math.min (this.high, other.high);
        return make(ilow, ihigh);
    }

    public boolean disjoint(Interval that){
        return this.high <= that.low || that.high <= this.low;
    }

    public boolean contains(Interval that){
        return this.low <= that.low && this.high >= that.high;
    }

}

class Rectangle{
    private Interval hor, vert;

    public Rectangle(Interval h, Interval v){
        hor  = h;
        vert = v;
    }
    public String toString(){
      return "(" + hor.toString() + "," + vert.toString() + ")";
    }

    public static Rectangle make(Interval h, Interval v){
        if (h != null && v != null)
            return new Rectangle(h,v);
        else
            return null;
    }

    public static Rectangle make(int xl, int yl, int xh, int yh){
       Interval hor  = Interval.make(xl, xh);
       Interval vert = Interval.make(yl, yh);
       return make(hor, vert);
    }

    public int area(){
        return hor.length() * vert.length();
    }

    public boolean disjoint (Rectangle that){
        return this.hor.disjoint(that.hor) ||
               this.vert.disjoint(that.vert);
    }

    public boolean contains(Rectangle that){
        return this.hor.contains(that.hor) && this.vert.contains(that.vert);
    }

}


class RectangleSet{
    public Vector rectangles = new Vector();

    public void add(Rectangle r){
        if (r != null)
            rectangles.addElement(r);
    }

    public boolean areDisjoint(){
        boolean disjoint = true;
        for (int k = 0; k < rectangles.size()&& disjoint; k++){
            Rectangle one = (Rectangle) rectangles.elementAt(k);
            for (int l = k + 1; l < rectangles.size()&& disjoint; l++){
                Rectangle two = (Rectangle) rectangles.elementAt(l);
                disjoint = one.disjoint(two);
            }
        }
        return disjoint;
    }

    public boolean containedIn(Rectangle floor){
        boolean contained = true;
        for (int k = 0; k < rectangles.size()&& contained; k++){
            Rectangle tile = (Rectangle) rectangles.elementAt(k);
            contained = floor.contains(tile);
        }
        return contained;
    }

    public int sumOfAreas(){
        int area = 0;
        for (int k = 0; k < rectangles.size(); k++){
            Rectangle tile = (Rectangle) rectangles.elementAt(k);
            area += tile.area();
        }
        return area;
    }


    public String toString(){
      String answer = "";
      for (int k = 0; k < rectangles.size(); k++){
            Object tile =  rectangles.elementAt(k);
            answer += tile.toString() + "\n";
        }
      return answer;
    }
}
