#include <stdio.h>
MIN(a,b){return a<b?a:b;}MAX(a,b){return a>b?a:b;}main(){int A,V,X,Y,Z,T,N,C[
100][4],i,j;for(freopen("h.in","r",stdin),scanf("%d",&T);T--;puts(V?"NONDISJ"
"OINT":Z?"NONCONTAINED":A<X*Y?"NONCOVERING":"OK"))for(scanf("%d%d%d",&X,&Y,&N
),i=V=A=Z=0;i<N;i++){scanf("%d%d%d%d",C[i],C[i]+1,C[i]+2,C[i]+3);A+=(C[i][2]-
C[i][0])*(C[i][3]-C[i][1]);for(j=0;j<i;j++)V|=(MAX(C[i][0],C[j][0])<MIN(C[i][
2],C[j][2]))&&(MAX(C[i][1],C[j][1])<MIN(C[i][3],C[j][3]));Z|=MAX((unsigned)C[
i][0],(unsigned)C[i][2])>X|MAX((unsigned)C[i][1],(unsigned)C[i][3])>Y;}return 0;}
