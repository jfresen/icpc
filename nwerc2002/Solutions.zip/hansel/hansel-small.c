#include <stdio.h>
main(){int T;double E,F,a,G,H,b,W,X,Y,Z,Q=57.29577951;for(freopen("c.in","r",stdin),scanf("%d",
&T);T--;){scanf("%lf%lf%lf%lf%lf%lf",&E,&F,&a,&G,&H,&b);sincos(a/=Q,&W,&X);sincos(b/=Q,&Y,&Z);a
=sin(a-b);printf("%.4f %.4f\n",(G*Z*W-Y*(E*X+(H-F)*W))/a,(F*Z*W-X*(H*Y+(E-G)*Z))/a);}return 0;}
