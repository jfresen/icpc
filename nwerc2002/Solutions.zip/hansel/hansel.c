/*
 * NWERC 2002: Handel and Grethel
 * Philipp Hahn <pmhahn@acm.org>
 */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>

#ifndef M_PI
# define M_PI           3.14159265358979323846  /* pi */
#endif

int X0, Y0, D0;
int X1, Y1, D1;
double x, y;

int main(void) {
	int n;
	freopen("c.in","r",stdin);
	/* Read number of test cases */
	assert( scanf("%d", &n) == 1 );
	while (n--) {
		scanf("%d%d%d", &X0, &Y0, &D0);
		assert( 0<=X0 && X0<=100 );
		assert( 0<=Y0 && Y0<=100 );
		assert( 0<=D0 && D0<360 );
		scanf("%d%d%d", &X1, &Y1, &D1);
		assert( 0<=X1 && X1<=100 );
		assert( 0<=Y1 && Y1<=100 );
		assert( 0<=D1 && D1<360 );
		assert( D0!=D1%180 );
		if (D0==90 || D0==270) {
			x=X1+(Y0-Y1)*tan(D1*M_PI/180);
			y=Y0;
		} else
		if (D1==90 || D1==270) {
			x=X0+(Y1-Y0)*tan(D0*M_PI/180);
			y=Y1;
		} else
		if (D0==0 || D0==180) {
			x=X0;
			y=Y1+(X0-X1)/tan(D1*M_PI/180);
		} else
		if (D1==0 || D1==180) {
			x=X1;
			y=Y0+(X1-X0)/tan(D0*M_PI/180);
		} else {
			double sin0=sin(D0*M_PI/180.0), cos0=cos(D0*M_PI/180.0);
			double sin1=sin(D1*M_PI/180.0), cos1=cos(D1*M_PI/180.0);
			double det=sin0*cos1-cos0*sin1;
			double X=(Y0*sin0-X0*cos0);
			double Y=(Y1*sin1-X1*cos1);
			x=(sin1*X-sin0*Y)/det;
			y=(cos1*X-cos0*Y)/det;
		}

		printf("%.4f %.4f\n", x, y);
	}
	return 0;
}
/* vim: tabstop=4 shiftwidth=4
 */
