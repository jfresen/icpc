import java.io.*;

public class Hansel
{
    public static void main(String[] args)
    {
        int aantalSituaties;

        try
        {
            StreamTokenizer f = new StreamTokenizer(new FileReader("c.in"));
            f.resetSyntax();
            f.whitespaceChars(0, 0x20);
            f.wordChars(0x21, 0xff);
            f.nextToken();
            aantalSituaties = Integer.parseInt(f.sval);

            for (int i = 0; i < aantalSituaties; i++)
            {
                // lees punt A in
                f.nextToken();
                int xA = Integer.parseInt(f.sval);
                f.nextToken();
                int yA = Integer.parseInt(f.sval);
                f.nextToken();
                int dA = Integer.parseInt(f.sval);
                Punt puntA = new Punt(xA, yA);

                // lees punt B in
                f.nextToken();
                int xB = Integer.parseInt(f.sval);
                f.nextToken();
                int yB = Integer.parseInt(f.sval);
                f.nextToken();
                int dB = Integer.parseInt(f.sval);
                Punt puntB = new Punt(xB, yB);

                // bereken de x- en y-coordinaten van het punt waarin Hans
                // en Grietje zich bevinden

                // bepaal lijn door punt A
                Lijn lijnA = new Lijn(puntA, dA);

                // bepaal lijn door punt B
                Lijn lijnB = new Lijn(puntB, dB);

                // bepaal het snijpunt tussen lijn 1 en lijn 2
                Punt puntHG = lijnA.getSnijpunt(lijnB);

                double xHG = puntHG.getX();
                double yHG = puntHG.getY();

                // print het resultaat
                System.out.println(stringVanDoubleIn4Decimalen(xHG) + " " + stringVanDoubleIn4Decimalen(yHG));
            }
        } catch (IOException e) {System.err.println(e);}

    }

    public static String stringVanDoubleIn4Decimalen(double d)
    {
        String s = "";

        d = Math.round(d * 10000.0);
        int i = (int) d;

        int j = i / 10000;

        s = s + j + ".";

        i = i - (j * 10000);

        String stringI = "" + i;
        while (stringI.length() < 4)
        {
            stringI = "0" + stringI;
        }

        s = s + stringI;

        return s;
    }
}

class Punt
{
    double x;
    double y;

    public Punt(double xIn, double yIn)
    {
        x = xIn;
        y = yIn;
    }

    public double getX()
    {
        return x;
    }

    public double getY()
    {
        return y;
    }
}

class Lijn
{
    // y = ax + b;
    public double a;
    public double b;
    public double xCoordinaat;
    public boolean verticaleLijn = false;

    public Lijn(Punt p, int d)
    {
        double pX = p.getX();
        double pY = p.getY();

        // hoek op 'normale' manier
        double h = 90.0 - d;

        // in radialen
        double r = (h / 360.0) * 2.0 * Math.PI;

        if (d == 0 || d == 180)
        {
            // verticale lijn
            verticaleLijn = true;
            xCoordinaat = pX;
        }
        else
        {
            a = Math.tan(r);
            b = pY - (a * pX);
        }
    }

    public boolean isVerticaleLijn()
    {
        return verticaleLijn;
    }

    public Punt getSnijpunt(Lijn lijnB)
    {
        double xSnijpunt;
        double ySnijpunt;

        if (this.isVerticaleLijn())
        {
            xSnijpunt = this.xCoordinaat;
            ySnijpunt = (lijnB.a * xSnijpunt) + lijnB.b;
        }
        else if (lijnB.isVerticaleLijn())
        {
            xSnijpunt = lijnB.xCoordinaat;
            ySnijpunt = (this.a * xSnijpunt) + this.b;
        }
        else // beide geen verticale lijn
        {
            xSnijpunt = (lijnB.b - this.b) / (this.a - lijnB.a);
            ySnijpunt = (this.a * xSnijpunt) + this.b;
        }

        Punt p = new Punt(xSnijpunt, ySnijpunt);
        return p;
    }
}
