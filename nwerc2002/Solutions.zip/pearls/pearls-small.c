#include <stdio.h>

main(){int r[101],s[101],m,n,j,k,c,d,l;for(freopen("f.in","r",stdin),scanf(
"%d",&m);m--;printf("%d\n",r[n])){scanf("%d",&n);for(*s=l=*r=j=0;j<n;j++){
scanf("%d%d",&d,&c);r[j+1]=(1<<31-1);s[j+1]=s[j]+d;for(k=l;k<j+1;k++)(c*(s[
j+1]-s[k]+10)+r[k]<r[j+1])?l=k,r[j+1]=c*(s[j+1]-s[k]+10)+r[k]:0;}}return 0;}
