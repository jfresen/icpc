/*************************************************************************************************************/
/*** Implementation for problem Pearls
***/
/*** David Solinger, 2002
***/
/*** NWERC Delft, 2002
***/
/*************************************************************************************************************/

/**************************************************************************************************************

The algorithm is in fact a shortest path algorithm. The nodes are the quality classes. A path from A to B can be 
described as: buy all the pearls in the classes A+1...B for the price in class B with only one amount of 10 
pearls extra in class B. So a path from A to B only exists if class A is lower then class B.

We keep track of all the best solutions so far in the array 'solution'. When the shortest path in the array is
in solution['last class'], the problem is solved.

***************************************************************************************************************/


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;


public class Pearls
{

  public static void main (String args[]) { new Pearls(); }	


  int num;							// variable num of classes
  int input[][]  = new int[100][2];				// variable input (num, price)
  int solution[] = new int[101];				// variable shortest path array


  int solve ()
  {
    solution[0] = 0;						// it takes 0 to buy pearls up till class 0
    for (int i = 1; i <= num; i++)
      solution[i] = Integer.MAX_VALUE;				// initiate the rest on MAX_VALUE
    while (true)						// keep looping untill we the solution is returned
    {
      int min = 0, sum = 0;					// initiate min and sum on 0 each loop
      for (int i = 1; i <= num; i++) 
        if (solution[i] < solution[min]) min = i;		// search for the minimum in solution
      if (min == num) return solution[num];			// stop when the last element is the minimum, with price solution[num] we can buy all pearls
      for (int i = min + 1; i <= num; i++)			// try to improve solution for each class higher then min
      {
        sum += input[i-1][0];					// sum of pearls from class min+1 till class i
        int val = (sum + 10) * input[i-1][1] + solution[min];	// account price to buy all pearls from classes min+1 till i in class i
        if (val < solution[i]) solution[i] = val;		// if this price is better then we had so far, take it
      }
      solution[min] = Integer.MAX_VALUE;			// forget the min we just handled
    }
  }


  public Pearls ()
  {
    try
    {
      StringTokenizer st;
      BufferedReader br = new BufferedReader(new FileReader("f.in"));
      int n = Integer.parseInt(br.readLine());			// read num of runs
      while (n-- > 0)						// run each run
      {
        num = Integer.parseInt(br.readLine());
        for (int i = 0; i < num; i++)				// read num of classes
        {
          st = new StringTokenizer(br.readLine());		// read single class 'i' with a num of pearls and a price
          for (int j = 0; j < 2; j++) 
            input[i][j] = Integer.parseInt(st.nextToken());
        }
        System.out.println(solve());				// print out the solution
      }
    }
    catch (IOException e) { System.err.println(e); }		// catch IO errors
  }

}
