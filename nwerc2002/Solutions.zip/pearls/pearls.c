/******************************************************************************
* Sample solution for the Pearls problem in NWERC 2002.
* Author: Andreas Bj�rklund
*
* Time complexity O(n^2), where n is the number of quality classes.
******************************************************************************/

#include <stdio.h>
#define MAX_QUALITY_CLASSES (101)
int cumsumdem[MAX_QUALITY_CLASSES];
int sol[MAX_QUALITY_CLASSES];
int main(void)
{
  int m,n,i,j,k,cost,dem,last;
  freopen("f.in","r",stdin);
  scanf("%d",&m);
  for (i=0;i<m;i++)
  {
    scanf("%d",&n);
    cumsumdem[0] = 0;last = 0;sol[0] = 0;
    for (j=0;j<n;j++)
    {
      scanf("%d %d",&dem,&cost);
      sol[j+1] = 0x7fffffff; cumsumdem[j+1] = cumsumdem[j]+dem;
      for (k=last;k<j+1;k++)
      {
        if (cost*(cumsumdem[j+1]-cumsumdem[k]+10)+sol[k] < sol[j+1])
        {
          last = k;
          sol[j+1] = cost*(cumsumdem[j+1]-cumsumdem[k]+10)+sol[k];
        }
      }
    }
    printf("%d\n",sol[n]);
  }
  return 0;
}
